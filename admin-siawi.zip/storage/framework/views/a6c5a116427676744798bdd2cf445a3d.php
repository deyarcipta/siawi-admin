

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Data Absensi Siswa</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Data Absensi Siswa</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Pilih Kelas</h3>
                    </div>
                    <div class="card-body">
                        <form action="/admin/dataAbsen" method="GET">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="kelas">Kelas</label>
                                    <select class="form-control" id="kelas" name="kelas" required>
                                        <option value="">Pilih Kelas</option>
                                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kls->id_kelas); ?>" <?php echo e($kelasId == $kls->id_kelas ? 'selected' : ''); ?>><?php echo e($kls->nama_kelas); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>&nbsp;</label> <!-- Label kosong untuk membuat tombol sejajar dengan input -->
                                        <button type="submit" class="btn btn-primary btn-block">Tampilkan Data</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($siswa)): ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Data Absensi</h3>
                    </div>
                    <div class="card-body">
                        <table style="font-size: 18px;">
                          <tr>
                            <td style="font-weight:bold" width="80">Kelas</td>
                            <td width="10">:</td>
                            <td><?php echo e($dataKelas->nama_kelas); ?></td>
                          </tr>
                        </table>
                        <form action="/admin/absensi/absen" method="POST">
                            <?php echo csrf_field(); ?>
                            <table id="" class="table table-bordered table-hover mt-2">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">No</th>
                                        <th>Nama Siswa</th>
                                        <th>Total Absen</th>
                                        <th>Masuk</th>
                                        <th>S</th>
                                        <th>I</th>
                                        <th>A</th>
                                        <th>Total Tidak Hadir</th>
                                        <th>Presentae</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->nama_siswa); ?></td>
                                        <td><?php echo e($absensiSiswa[$data->id_siswa]); ?></td> <!-- Menampilkan total absensi -->
                                        <td><?php echo e($countMasuk[$data->id_siswa]); ?></td> <!-- Menampilkan jumlah masuk -->
                                        <td><?php echo e($countSakit[$data->id_siswa]); ?></td> <!-- Menampilkan jumlah sakit -->
                                        <td><?php echo e($countIzin[$data->id_siswa]); ?></td> <!-- Menampilkan jumlah izin -->
                                        <td><?php echo e($countAlfa[$data->id_siswa]); ?></td> <!-- Menampilkan jumlah alfa -->
                                        <td><?php echo e($countAlfa[$data->id_siswa] + $countIzin[$data->id_siswa] + $countSakit[$data->id_siswa]); ?></td>
                                        <td>
                                            <?php
                                            $presentase = ($countMasuk[$data->id_siswa]/$absensiSiswa[$data->id_siswa])*100; // Misalkan presentase diambil dari variabel $presentase
                                            $badgeClass = '';

                                            if ($presentase > 90) {
                                                $badgeClass = 'badge-success';
                                            } elseif ($presentase >= 80 && $presentase <= 90) {
                                                $badgeClass = 'badge-warning';
                                            } else {
                                                $badgeClass = 'badge-danger';
                                            }
                                            ?>
                                            <span class="badge <?php echo e($badgeClass); ?>"><?php echo e($presentase); ?>%</span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\admin-siawi\resources\views/dataAbsen/data_absen.blade.php ENDPATH**/ ?>