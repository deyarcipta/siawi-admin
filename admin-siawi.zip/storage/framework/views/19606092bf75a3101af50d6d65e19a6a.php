    <!-- Main Footer -->
    <footer class="main-footer">
      <!-- To the right -->
      <div class="float-right d-none d-sm-inline">
        <?php echo e($setting->nama_sekolah); ?>

      </div>
      <!-- Default to the left -->
      <strong>Copyright &copy; 2024 <a href="#">Deyar Cipta Rizky</a>.</strong>
    </footer><?php /**PATH C:\laragon\www\admin-siawi\resources\views/partials/footer.blade.php ENDPATH**/ ?>