
<?php $__env->startSection('content'); ?>
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Edit Rapot</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Rapot</a></li>
            <li class="breadcrumb-item active">Edit Rapot</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <!-- general form elements -->
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Form Edit Rapot</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="/admin/rapot/<?php echo e($edit->id_rapot); ?>" method="POST"  enctype="multipart/form-data">
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="card-body">
                <div class="row">
                  <div class="form-group col-6">
                    <label for="nama_siswa">Siswa</label>
                    <input type="text" class="form-control" name="nama_siswa" id="nama_siswa" value="<?php echo e($edit->siswa->nama_siswa); ?>" disabled>

                    <input type="text" class="form-control" name="id_siswa" id="id_siswa" value="<?php echo e($edit->id_siswa); ?>" hidden>
                    <?php $__errorArgs = ['id_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="semester">Semester</label>
                    <select class="form-control" name="semester" id="semester">
                      <option value="">Pilih Semester</option>
                      <option value="1" <?php echo e($edit->semester == 1 ? 'selected' : ''); ?>>Semester 1</option>
                      <option value="2" <?php echo e($edit->semester == 2 ? 'selected' : ''); ?>>Semester 2</option>
                      <option value="3" <?php echo e($edit->semester == 3 ? 'selected' : ''); ?>>Semester 3</option>
                      <option value="4" <?php echo e($edit->semester == 4 ? 'selected' : ''); ?>>Semester 4</option>
                      <option value="5" <?php echo e($edit->semester == 5 ? 'selected' : ''); ?>>Semester 5</option>
                      <option value="6" <?php echo e($edit->semester == 6 ? 'selected' : ''); ?>>Semester 6</option>
                    </select>
                    <?php $__errorArgs = ['semester'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="form-group">
                  <label for="file_rapot">File Rapot</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" name="file_rapot" id="file_rapot">
                        <label class="custom-file-label" id="file_rapot-label" for="file_rapot">Choose file</label>
                        <script>
                          document.getElementById('file_rapot').addEventListener('change', function(e) {
                              var fileName = e.target.files[0].name;
                              var label = document.getElementById('file_rapot-label');
                              label.textContent = fileName;
                          });
                      </script>
                    </div>
                </div>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <input type="text" name="id_kelas" id="id_kelas" value="<?php echo e($edit->id_kelas); ?>" hidden>
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.card -->
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\admin-siawi\resources\views/rapot/edit_rapot.blade.php ENDPATH**/ ?>