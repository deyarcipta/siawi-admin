

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Absensi Siswa</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Absensi Siswa</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Pilih Tanggal dan Kelas</h3>
                    </div>
                    <div class="card-body">
                        <form action="/admin/absensi" method="GET">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-6">
                                    <label for="tanggal">Tanggal</label>
                                    <input type="date" class="form-control" id="tanggal" name="tanggal" required value="<?php echo e($tanggal ?? ''); ?>">
                                </div>
                                <div class="form-group col-6">
                                    <label for="kelas">Kelas</label>
                                    <select class="form-control" id="kelas" name="kelas" required>
                                        <option value="">Pilih Kelas</option>
                                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kls->id_kelas); ?>" <?php echo e($kelasId == $kls->id_kelas ? 'selected' : ''); ?>><?php echo e($kls->nama_kelas); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Tampilkan Data</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($siswa)): ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Data Absensi</h3>
                    </div>
                    <div class="card-body">
                        <table style="font-size: 18px;">
                          <tr>
                            <td style="font-weight:bold" width="80">Tanggal</td>
                            <td width="10">:</td>
                            <td><?php echo e($namaHari); ?>, <?php echo e($tanggal); ?></td>
                          </tr>
                          <tr>
                            <td style="font-weight:bold" width="80">Kelas</td>
                            <td width="10">:</td>
                            <td><?php echo e($dataKelas->nama_kelas); ?></td>
                          </tr>
                        </table>
                        <form action="/admin/absensi/absen" method="POST">
                            <?php echo csrf_field(); ?>
                            <table id="" class="table table-bordered table-hover mt-2">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">#</th>
                                        <th style="width: 10px">No</th>
                                        <th>Nama Siswa</th>
                                        <th>Kehadiran</th>
                                        <th>Keterangan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><input type="checkbox" name="siswa[<?php echo e($data->id_siswa); ?>][checkbox]" value="hadir"></td>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                          <input type="hidden" name="siswa[<?php echo e($data->id_siswa); ?>][id_siswa]" value="<?php echo e($data->id_siswa); ?>"><?php echo e($data->nama_siswa); ?>

                                        </td>
                                        <td>
                                          <select class="form-control" name="siswa[<?php echo e($data->id_siswa); ?>][kehadiran]">
                                            <option value="hadir" <?php echo e(isset($absensiSiswa[$data->id_siswa]) && $absensiSiswa[$data->id_siswa]->kehadiran == 'hadir' ? 'selected' : ''); ?>>Hadir</option>
                                            <option value="sakit" <?php echo e(isset($absensiSiswa[$data->id_siswa]) && $absensiSiswa[$data->id_siswa]->kehadiran == 'sakit' ? 'selected' : ''); ?>>Sakit</option>
                                            <option value="izin" <?php echo e(isset($absensiSiswa[$data->id_siswa]) && $absensiSiswa[$data->id_siswa]->kehadiran == 'izin' ? 'selected' : ''); ?>>Izin</option>
                                            <option value="alfa" <?php echo e(isset($absensiSiswa[$data->id_siswa]) && $absensiSiswa[$data->id_siswa]->kehadiran == 'alfa' ? 'selected' : ''); ?>>Alfa</option>
                                        </select>
                                        </td>
                                        <td>
                                            <input class="form-control" type="text" name="siswa[<?php echo e($data->id_siswa); ?>][keterangan]" value="<?php echo e($absensiSiswa[$data->id_siswa]->keterangan ?? ''); ?>">
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <input type="hidden" name="tanggal" value="<?php echo e($tanggal); ?>">
                            <input type="hidden" name="kelas_id" value="<?php echo e($dataKelas->id_kelas); ?>">
                            <input type="hidden" name="hari" value="<?php echo e($namaHari); ?>">
                            
                            <button type="submit" class="btn btn-primary">Simpan Kehadiran</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\admin-siawi\resources\views/absensi/data_absensi.blade.php ENDPATH**/ ?>