
<?php $__env->startSection('content'); ?>
  <!-- Content Header (Page header) -->
  <div class="content-header">
    <div class="container-fluid">
      <div class="row mb-2">
        <div class="col-sm-6">
          <h1 class="m-0">Edit Siswa</h1>
        </div><!-- /.col -->
        <div class="col-sm-6">
          <ol class="breadcrumb float-sm-right">
            <li class="breadcrumb-item"><a href="#">Siswa</a></li>
            <li class="breadcrumb-item active">Edit Siswa</li>
          </ol>
        </div><!-- /.col -->
      </div><!-- /.row -->
    </div><!-- /.container-fluid -->
  </div>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <!-- general form elements -->
          <div class="card card-primary">
            <div class="card-header">
              <h3 class="card-title">Form Edit Siswa</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <form action="/admin/siswa/<?php echo e($edit->id_siswa); ?>" method="POST" enctype="multipart/form-data">
              <?php echo method_field('PUT'); ?>
              <?php echo csrf_field(); ?>
              <div class="card-body">
                <span style="font-size: 16; font-weight:bold;">Data Diri Siswa</span>
                <div class="row mt-2">
                  <div class="form-group col-6">
                    <label for="nis">NIS</label>
                    <input type="text" readonly class="form-control" id="nis" placeholder="Enter Nis" name="nis" value="<?php echo e($edit->nis); ?>">
                    <?php $__errorArgs = ['nis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="nisn">NISN</label>
                    <input type="text" class="form-control" id="nisn" placeholder="Enter Nisn" name="nisn" value="<?php echo e($edit->nisn); ?>">
                    <?php $__errorArgs = ['nisn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-6">
                    <label for="nama_siswa">Nama Siswa</label>
                    <input type="text" class="form-control" id="nama_siswa" placeholder="Enter Nama Siswa" name="nama_siswa" value="<?php echo e($edit->nama_siswa); ?>">
                    <?php $__errorArgs = ['nama_siswa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="password">Password</label>
                    <input type="text" class="form-control" id="password" placeholder="Enter password" name="password" value="<?php echo e($edit->password); ?>">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-4">
                    <label for="kode_level">Pilih Level</label>
                    <select class="form-control" name="kode_level" id="kode_level">
                        <option value="<?php echo e($edit->level); ?>"><?php echo e($edit->level); ?></option>
                      <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($lvl->kode_level); ?>"><?php echo e($lvl->kode_level); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['kode_level'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="kode_kelas">Pilih Kelas</label>
                    <select class="form-control" name="kode_kelas" id="kode_kelas">
                      <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($kls->id_kelas); ?>" <?php echo e($edit->id_kelas == $kls->id ? 'selected' : ''); ?>> <?php echo e($kls->nama_kelas); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['kode_kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="kode_jurusan">Pilih Jurusan</label>
                    <select class="form-control" name="kode_jurusan" id="kode_jurusan">
                      <option value="<?php echo e($edit->jurusan); ?>"><?php echo e($edit->jurusan); ?></option>
                      <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jur): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($jur->kode_jurusan); ?>"><?php echo e($jur->kode_jurusan); ?></option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['kode_jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-3">
                    <label for="tmpt_lahir">Tempat Lahir</label>
                    <input type="text" class="form-control" id="tmpt_lahir" placeholder="Enter Tempat Lahir" name="tmpt_lahir" value="<?php echo e($edit->tmpt_lahir); ?>">
                    <?php $__errorArgs = ['tmpt_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-3">
                    <label for="tgl_lahir">Tanggal Lahir</label>
                    <input type="date" class="form-control" id="tgl_lahir" placeholder="Enter tgl_lahir" name="tgl_lahir" value="<?php echo e($edit->tgl_lahir); ?>">
                    <?php $__errorArgs = ['tgl_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-3">
                    <label for="agama">Agama</label>
                    <select class="form-control" name="agama" id="agama">
                      <option value="<?php echo e($edit->agama); ?>"><?php echo e($edit->agama); ?></option>
                      <option value="islam">Islam</option>
                      <option value="katolik">Katolik</option>
                      <option value="protestan">Protestan</option>
                      <option value="hindu">Hindu</option>
                      <option value="budha">Budha</option>
                    </select>
                    <?php $__errorArgs = ['agama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-3">
                    <label for="jenis_kelamin">Jenis Kelamin</label>
                    <select class="form-control" name="jenis_kelamin" id="jenis_kelamin">
                      <option value="<?php echo e($edit->jenis_kelamin); ?>">
                        <?php if($edit->jenis_kelamin == "L"): ?>
                          Laki - Laki
                        <?php else: ?>
                          Perempuan
                        <?php endif; ?>
                      </option>
                      <option value="L">Laki-laki</option>
                      <option value="P">Perempuan</option>
                    </select>
                    <?php $__errorArgs = ['jenis_kelamin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-3">
                    <label for="no_hp">No HP</label>
                    <input type="text" class="form-control" id="no_hp" placeholder="Enter No Hp" name="no_hp" value="<?php echo e($edit->no_hp); ?>">
                    <?php $__errorArgs = ['no_hp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-3">
                    <label for="no_tlpn">No. Telp</label>
                    <input type="text" class="form-control" id="no_tlpn" placeholder="Enter No. Telp" name="no_tlpn" value="<?php echo e($edit->no_tlpn); ?>">
                    <?php $__errorArgs = ['no_tlpn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-3">
                    <label for="email">Email</label>
                    <input type="text" class="form-control" id="email" placeholder="Enter Email" name="email" value="<?php echo e($edit->email); ?>">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-3">
                    <label for="foto">Foto Siswa</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" name="foto" id="foto">
                        <label class="custom-file-label" id="foto-label" for="foto">Choose file</label>
                        <script>
                          document.getElementById('foto').addEventListener('change', function(e) {
                              var fileName = e.target.files[0].name;
                              var label = document.getElementById('foto-label');
                              label.textContent = fileName;
                          });
                      </script>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-12">
                    <label for="alamat">Alamat</label>
                    <textarea class="form-control" id="alamat" placeholder="Enter Alamat" name="alamat" value="<?php echo e($edit->alamat); ?>"><?php echo e($edit->alamat); ?></textarea>
                    <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-2">
                    <label for="rt">RT</label>
                    <input type="text" class="form-control" id="rt" placeholder="Enter RT" name="rt" value="<?php echo e($edit->rt); ?>">
                    <?php $__errorArgs = ['rt'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-2">
                    <label for="rw">RW</label>
                    <input type="text" class="form-control" id="rw" placeholder="Enter RW" name="rw" value="<?php echo e($edit->rw); ?>">
                    <?php $__errorArgs = ['rw'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-2">
                    <label for="no_rumah">No. Rumah</label>
                    <input type="text" class="form-control" id="no_rumah" placeholder="Enter No Rumah" name="no_rumah" value="<?php echo e($edit->no_rumah); ?>">
                    <?php $__errorArgs = ['no_rumah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="kel">Kelurahan</label>
                    <input type="text" class="form-control" id="kel" placeholder="Enter Kelurahan" name="kel" value="<?php echo e($edit->kel); ?>">
                    <?php $__errorArgs = ['kel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row mb-2">
                  <div class="form-group col-4">
                    <label for="kec">Kecamatan</label>
                    <input type="text" class="form-control" id="kec" placeholder="Enter Kecamatan" name="kec" value="<?php echo e($edit->kec); ?>">
                    <?php $__errorArgs = ['kec'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="kota">Kota</label>
                    <input type="text" class="form-control" id="kota" placeholder="Enter Kota" name="kota" value="<?php echo e($edit->kota); ?>">
                    <?php $__errorArgs = ['kota'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="prov">Provinsi</label>
                    <input type="text" class="form-control" id="prov" placeholder="Enter Provinsi" name="prov" value="<?php echo e($edit->prov); ?>">
                    <?php $__errorArgs = ['prov'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <span style="font-size: 16; font-weight:bold;">Data Orang Tua ( ayah )</span>
                <div class="row mt-2">
                  <div class="form-group col-6">
                    <label for="nik_ayah">NIK Ayah</label>
                    <input type="text" class="form-control" id="nik_ayah" placeholder="Enter NIK Ayah" name="nik_ayah" value="<?php echo e($edit->nik_ayah); ?>">
                    <?php $__errorArgs = ['nik_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="nama_ayah">Nama Ayah</label>
                    <input type="text" class="form-control" id="nama_ayah" placeholder="Enter Nama Ayah" name="nama_ayah" value="<?php echo e($edit->nama_ayah); ?>">
                    <?php $__errorArgs = ['nama_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-4">
                    <label for="tmpt_lahir_ayah">Tempat Lahir Ayah</label>
                    <input type="text" class="form-control" id="tmpt_lahir_ayah" placeholder="Enter Tempat Lahir Ayah" name="tmpt_lahir_ayah" value="<?php echo e($edit->tmpt_lahir_ayah); ?>">
                    <?php $__errorArgs = ['tmpt_lahir_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="tgl_lahir_ayah">Tanggal Lahir Ayah</label>
                    <input type="date" class="form-control" id="tgl_lahir_ayah" name="tgl_lahir_ayah" value="<?php echo e($edit->tgl_lahir_ayah); ?>">
                    <?php $__errorArgs = ['tgl_lahir_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="pendidikan_ayah">Pendidikan Ayah</label>
                    <select class="form-control" name="pendidikan_ayah" id="pendidikan_ayah">
                      <option value="<?php echo e($edit->pendidikan_ayah); ?>"><?php echo e($edit->pendidikan_ayah); ?></option>
                      <option value="sd">SD</option>
                      <option value="smp">SMP</option>
                      <option value="sma">SMA/SMK</option>
                      <option value="s1">S1</option>
                      <option value="s2">S2</option>
                      <option value="s3">S3</option>
                    </select>
                    <?php $__errorArgs = ['pendidikan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row mb-2">
                  <div class="form-group col-6">
                    <label for="pekerjaan_ayah">Pekerjaan Ayah</label>
                    <select class="form-control" name="pekerjaan_ayah" id="pekerjaan_ayah">
                      <option value="<?php echo e($edit->pekerjaan_ayah); ?>"><?php echo e($edit->pekerjaan_ayah); ?></option>
                      <option value="karyawan">Karyawan</option>
                      <option value="pns">PNS</option>
                      <option value="tni/polisi">TNI/POLISI</option>
                      <option value="wiraswasta">Wiraswasta</option>
                      <option value="guru">Guru</option>
                      <option value="lainnya">Lainnya</option>
                    </select>
                    <?php $__errorArgs = ['pekerjaan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="penghasilan_ayah">Penghasilan Ayah</label>
                    <select class="form-control" name="penghasilan_ayah" id="penghasilan_ayah">
                      <option value="<?php echo e($edit->penghasilan_ayah); ?>"><?php echo e($edit->penghasilan_ayah); ?></option>
                      <option value="-">-</option>
                      <option value="Rp.500.000 - Rp 2.000.000">Rp.500.000 - Rp 2.000.000</option>
                      <option value="Rp.2.100.000 - Rp 3.000.000">Rp.2.100.000 - Rp 3.000.000</option>
                      <option value="Rp.3.100.000 - Rp 4.000.000">Rp.3.100.000 - Rp 4.000.000</option>
                      <option value="Rp.4.100.000 - Rp 5.000.000">Rp.4.100.000 - Rp 5.000.000</option>
                      <option value=">Rp.5.000.000">>Rp.5.000.000</option>
                    </select>
                    <?php $__errorArgs = ['penghasilan_ayah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <span style="font-size: 16; font-weight:bold;">Data Orang Tua ( ibu )</span>
                <div class="row mt-2">
                  <div class="form-group col-6">
                    <label for="nik_ibu">NIK Ibu</label>
                    <input type="text" class="form-control" id="nik_ibu" placeholder="Enter NIK ibu" name="nik_ibu" value="<?php echo e($edit->nik_ibu); ?>">
                    <?php $__errorArgs = ['nik_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="nama_ibu">Nama Ibu</label>
                    <input type="text" class="form-control" id="nama_ibu" placeholder="Enter Nama ibu" name="nama_ibu" value="<?php echo e($edit->nama_ibu); ?>">
                    <?php $__errorArgs = ['nama_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-4">
                    <label for="tmpt_lahir_ibu">Tempat Lahir Ibu</label>
                    <input type="text" class="form-control" id="tmpt_lahir_ibu" placeholder="Enter Tempat Lahir ibu" name="tmpt_lahir_ibu" value="<?php echo e($edit->tmpt_lahir_ibu); ?>">
                    <?php $__errorArgs = ['tmpt_lahir_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="tgl_lahir_ibu">Tanggal Lahir Ibu</label>
                    <input type="date" class="form-control" id="tgl_lahir_ibu" name="tgl_lahir_ibu" value="<?php echo e($edit->tgl_lahir_ibu); ?>">
                    <?php $__errorArgs = ['tgl_lahir_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="pendidikan_ibu">Pendidikan Ibu</label>
                    <select class="form-control" name="pendidikan_ibu" id="pendidikan_ibu">
                      <option value="<?php echo e($edit->pendidikan_ibu); ?>"><?php echo e($edit->pendidikan_ibu); ?></option>
                      <option value="sd">SD</option>
                      <option value="smp">SMP</option>
                      <option value="sma">SMA/SMK</option>
                      <option value="s1">S1</option>
                      <option value="s2">S2</option>
                      <option value="s3">S3</option>
                    </select>
                    <?php $__errorArgs = ['pendidikan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row mb-2">
                  <div class="form-group col-6">
                    <label for="pekerjaan_ibu">Pekerjaan Ibu</label>
                    <select class="form-control" name="pekerjaan_ibu" id="pekerjaan_ibu">
                      <option value="<?php echo e($edit->pekerjaan_ibu); ?>"><?php echo e($edit->pekerjaan_ibu); ?></option>
                      <option value="karyawan">Karyawan</option>
                      <option value="pns">PNS</option>
                      <option value="tni/polisi">TNI/POLISI</option>
                      <option value="wiraswasta">Wiraswasta</option>
                      <option value="guru">Guru</option>
                      <option value="ibu rumah tangga">Ibu Rumah Tangga</option>
                      <option value="lainnya">Lainnya</option>
                    </select>
                    <?php $__errorArgs = ['pekerjaan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="penghasilan_ibu">Penghasilan Ibu</label>
                    <select class="form-control" name="penghasilan_ibu" id="penghasilan_ibu">
                      <option value="<?php echo e($edit->penghasilan_ibu); ?>"><?php echo e($edit->penghasilan_ibu); ?></option>
                      <option value="-">-</option>
                      <option value="Rp.500.000 - Rp 2.000.000">Rp.500.000 - Rp 2.000.000</option>
                      <option value="Rp.2.100.000 - Rp 3.000.000">Rp.2.100.000 - Rp 3.000.000</option>
                      <option value="Rp.3.100.000 - Rp 4.000.000">Rp.3.100.000 - Rp 4.000.000</option>
                      <option value="Rp.4.100.000 - Rp 5.000.000">Rp.4.100.000 - Rp 5.000.000</option>
                      <option value=">Rp.5.000.000">>Rp.5.000.000</option>
                    </select>
                    <?php $__errorArgs = ['penghasilan_ibu'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <span style="font-size: 16; font-weight:bold;">Data Orang Tua ( wali )</span>
                <div class="row mt-2">
                  <div class="form-group col-6">
                    <label for="nik_wali">NIK Wali</label>
                    <input type="text" class="form-control" id="nik_wali" placeholder="Enter NIK wali" name="nik_wali" value="<?php echo e($edit->nik_wali); ?>">
                    <?php $__errorArgs = ['nik_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="nama_wali">Nama Wali</label>
                    <input type="text" class="form-control" id="nama_wali" placeholder="Enter Nama wali" name="nama_wali" value="<?php echo e($edit->nama_wali); ?>">
                    <?php $__errorArgs = ['nama_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row">
                  <div class="form-group col-4">
                    <label for="tmpt_lahir_wali">Tempat Lahir Wali</label>
                    <input type="text" class="form-control" id="tmpt_lahir_wali" placeholder="Enter Tempat Lahir wali" name="tmpt_lahir_wali" value="<?php echo e($edit->tmpt_lahir_wali); ?>">
                    <?php $__errorArgs = ['tmpt_lahir_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="tgl_lahir_wali">Tanggal Lahir Wali</label>
                    <input type="date" class="form-control" id="tgl_lahir_wali" name="tgl_lahir_wali" value="<?php echo e($edit->tgl_lahir_wali); ?>">
                    <?php $__errorArgs = ['tgl_lahir_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-4">
                    <label for="pendidikan_wali">Pendidikan Wali</label>
                    <select class="form-control" name="pendidikan_wali" id="pendidikan_wali">
                      <option value="<?php echo e($edit->pendidikan_wali); ?>"><?php echo e($edit->pendidikan_wali); ?></option>
                      <option value="sd">SD</option>
                      <option value="smp">SMP</option>
                      <option value="sma">SMA/SMK</option>
                      <option value="s1">S1</option>
                      <option value="s2">S2</option>
                      <option value="s3">S3</option>
                    </select>
                    <?php $__errorArgs = ['pendidikan_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
                <div class="row mb-2">
                  <div class="form-group col-6">
                    <label for="pekerjaan_wali">Pekerjaan Wali</label>
                    <select class="form-control" name="pekerjaan_wali" id="pekerjaan_wali">
                      <option value="<?php echo e($edit->pekerjaan_wali); ?>"><?php echo e($edit->pekerjaan_wali); ?></option>
                      <option value="karyawan">Karyawan</option>
                      <option value="pns">PNS</option>
                      <option value="tni/polisi">TNI/POLISI</option>
                      <option value="wiraswasta">Wiraswasta</option>
                      <option value="guru">Guru</option>
                      <option value="ibu rumah tangga">Ibu Rumah Tangga</option>
                      <option value="lainnya">Lainnya</option>
                    </select>
                    <?php $__errorArgs = ['pekerjaan_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                  <div class="form-group col-6">
                    <label for="penghasilan_wali">Penghasilan Wali</label>
                    <select class="form-control" name="penghasilan_wali" id="penghasilan_wali">
                      <option value="<?php echo e($edit->penghasilan_wali); ?>"><?php echo e($edit->penghasilan_wali); ?></option>
                      <option value="-">-</option>
                      <option value="Rp.500.000 - Rp 2.000.000">Rp.500.000 - Rp 2.000.000</option>
                      <option value="Rp.2.100.000 - Rp 3.000.000">Rp.2.100.000 - Rp 3.000.000</option>
                      <option value="Rp.3.100.000 - Rp 4.000.000">Rp.3.100.000 - Rp 4.000.000</option>
                      <option value="Rp.4.100.000 - Rp 5.000.000">Rp.4.100.000 - Rp 5.000.000</option>
                      <option value=">Rp.5.000.000">>Rp.5.000.000</option>
                    </select>
                    <?php $__errorArgs = ['penghasilan_wali'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>
                </div>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.card -->
        </div>
      </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\admin-siawi\resources\views/dataSiswa/edit_siswa.blade.php ENDPATH**/ ?>