

<?php $__env->startSection('content'); ?>
<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Tagihan Siswa</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">Tagihan Siswa</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Pilih Kelas</h3>
                        <a href="/admin/tagihan/1/edit" class="btn btn-success ml-auto">Edit Link</a>
                    </div>
                    <div class="card-body">
                        <form action="/admin/tagihan" method="GET">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="from-group col-2">
                                    <label for="kelas">Pilih Kelas</label>
                                </div>
                                <div class="form-group col-4">
                                    <select class="form-control" id="kelas" name="kelas" required>
                                        <option value="">Pilih Kelas</option>
                                        <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($kls->id_kelas); ?>" <?php echo e($kelasId == $kls->id_kelas ? 'selected' : ''); ?>><?php echo e($kls->nama_kelas); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="form-group col-2"> <!-- Menambahkan class text-right untuk menggeser ke kanan -->
                                    <button type="submit" class="btn btn-primary">Tampilkan Data</button>
                                </div>
                            </div>
                            
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php if(isset($siswa)): ?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header d-flex align-items-center">
                        <h3 class="card-title">Data Tagihan</h3>
                    </div>
                    <div class="card-body">
                        <form action="#" method="POST">
                            <?php echo csrf_field(); ?>
                            <table id="" class="table table-bordered table-hover mt-2">
                                <thead>
                                    <tr>
                                        <th style="width: 10px">No</th>
                                        <th>Nama Siswa</th>
                                        <th>Link tagihan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->nama_siswa); ?></td>
                                        <td>
                                            <a href="<?php echo e($tagihan->link); ?><?php echo e($data->nis); ?>" target="_blank"><?php echo e($tagihan->link); ?><?php echo e($data->nis); ?>

                                            </a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($layout, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\admin-siawi\resources\views/tagihan/data_tagihan.blade.php ENDPATH**/ ?>