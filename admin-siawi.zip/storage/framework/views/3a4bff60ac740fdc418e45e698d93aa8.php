<!-- Main Sidebar Container -->


<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">
  <!-- Brand Logo -->
  <a href="/admin/dashboard" class="brand-link">
    <img src="<?php echo e(asset("storage/gambar/$setting->logo")); ?>" alt="AdminLTE Logo" class="brand-image img-circle elevation-2" style="opacity: .8 box-shadow: 0px 0px 5px rgba(255, 255, 255, 0.8);">
    <span class="brand-text font-weight-bold"><?php echo e($setting->nama_app); ?></span>
  </a>

  <!-- Sidebar -->
  <div class="sidebar">
    <!-- Sidebar user (optional) -->
    <div class="user-panel mt-3 pb-3 mb-1 d-flex">
      <div class="image">
        <img src="<?php echo e(asset('lte/dist/img/default.jpg')); ?>" class="img-circle elevation-2" alt="User Image">
      </div>
      <div class="info">
        <a href="#" class="d-block"><?php echo e($user->nama_guru); ?></a>
      </div>
    </div>

    <!-- Sidebar Menu -->
    <nav class="mt-1">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
        <!-- Add icons to the links using the .nav-icon class
             with font-awesome or any other icon font library -->
        <li class="nav-item">
          <a href="/admin/dashboard" class="nav-link <?php echo e(Request::is('admin/dashboard') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-tachometer-alt"></i>
            <p>
              Dashboard
            </p>
          </a>
        </li>
        <?php if($user->role == 'admin'): ?>
        <li class="nav-item has-treeview <?php echo e(Request::is('admin/jurusan*') || Request::is('admin/importDataMaster*') || Request::is('admin/level*') || Request::is('admin/kelas*') || Request::is('admin/mapel*') || Request::is('admin/dataMaster/*') ? 'menu-open' : ''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('admin/jurusan*') || Request::is('admin/importDataMaster*') || Request::is('admin/level*') || Request::is('admin/kelas*') || Request::is('admin/mapel*') || Request::is('admin/dataMaster/*') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Data Master
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item" style="font-size: 14px">
              <a href="/admin/importDataMaster" class="nav-link <?php echo e(Request::is('admin/importDataMaster') ? 'active' : ''); ?>">
                <i class="fa fa-upload nav-icon" style="font-size: 14px"></i>
                <p>Import Data Master</p>
              </a>
            </li>
            <li class="nav-item" style="font-size: 14px">
              <a href="/admin/jurusan" class="nav-link <?php echo e(Request::is('admin/jurusan') ? 'active' : ''); ?>">
                <i class="fa fa-check nav-icon " style="color: lightgreen; font-size:14px"></i>
                <p>Data Jurusan</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/level" class="nav-link <?php echo e(Request::is('admin/level') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon" style="font-size: 14px"></i>
                <p>Data Level</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/kelas" class="nav-link <?php echo e(Request::is('admin/kelas') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon"  style="color: lightgreen; font-size:14px"></i>
                <p>Data Kelas</p>
              </a>
            </li>
            <li class="nav-item" style="font-size: 14px">
              <a href="/admin/mapel" class="nav-link <?php echo e(Request::is('admin/mapel') ? 'active' : ''); ?>">
                <i class="fa fa-check nav-icon " style="color: lightgreen; font-size:14px"></i>
                <p>Data Mata Pelajaran</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/siswa" class="nav-link <?php echo e(Request::is('admin/siswa') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>
              Data Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/informasi" class="nav-link <?php echo e(Request::is('admin/informasi') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-info-circle"></i>
            <p>
              Informasi Sekolah
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/kalender" class="nav-link <?php echo e(Request::is('admin/kalender') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-calendar-alt"></i>
            <p>
              Kalender Sekolah
            </p>
          </a>
        </li>
        <li class="nav-item has-treeview <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-edit"></i>
              <p>
                Data Abseni
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/absensi" class="nav-link <?php echo e(Request::is('admin/absensi') ? 'active' : ''); ?>">
                <i class="fa fa-check nav-icon" style="font-size: 14px"></i>
                <p>
                  Input Absensi Siswa
                </p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/dataAbsen" class="nav-link <?php echo e(Request::is('admin/dataAbsen') ? 'active' : ''); ?>">
                <i class="fa fa-check nav-icon" style="color: lightgreen; font-size:14px"></i>
                <p>
                  Data Absensi Siswa
                </p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/jadwal" class="nav-link <?php echo e(Request::is('admin/jadwal') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-calendar-check"></i>
            <p>
              Jadwal Mata Pelajaran
            </p>
          </a>
        </li>
        
        <li class="nav-item">
          <a href="/admin/rapot" class="nav-link <?php echo e(Request::is('admin/rapot') ? 'active' : ''); ?>">
            <i class="nav-icon far fa-image"></i>
            <p>
              E - Rapot
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/tagihan" class="nav-link <?php echo e(Request::is('admin/tagihan') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-columns"></i>
            <p>
              Tagihan
            </p>
          </a>
        </li>
        <li class="nav-item has-treeview <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'menu-open' : ''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Point Siswa
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/point" class="nav-link <?php echo e(Request::is('admin/point') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon" style="font-size: 14px"></i>
                <p>Data Point</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/pointSiswa" class="nav-link <?php echo e(Request::is('admin/pointSiswa') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon"  style="color: lightgreen; font-size:14px"></i>
                <p>Data Point Siswa</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/modul" class="nav-link <?php echo e(Request::is('admin/modul') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-book"></i>
            <p>
              Modul Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/berita" class="nav-link <?php echo e(Request::is('admin/berita') ? 'active' : ''); ?>">
            <i class="nav-icon far fa-plus-square"></i>
            <p>
              Berita
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/guru" class="nav-link <?php echo e(Request::is('admin/guru') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-search"></i>
            <p>
              Data Guru
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/setting" class="nav-link <?php echo e(Request::is('admin/setting') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-cog"></i>
            <p>
              Setting
            </p>
          </a>
        </li>
        <?php elseif($user->role == 'kurikulum'): ?>
        <li class="nav-item">
          <a href="/admin/siswa" class="nav-link <?php echo e(Request::is('admin/siswa') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>
              Data Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/informasi" class="nav-link <?php echo e(Request::is('admin/informasi') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-info-circle"></i>
            <p>
              Informasi Sekolah
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/kalender" class="nav-link <?php echo e(Request::is('admin/kalender') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-calendar-alt"></i>
            <p>
              Kalender Sekolah
            </p>
          </a>
        </li>
        <li class="nav-item has-treeview <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'menu-open' : ''); ?>">
            <a href="#" class="nav-link <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'active' : ''); ?>">
              <i class="nav-icon fas fa-th"></i>
              <p>
                Point Siswa
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/absensi" class="nav-link <?php echo e(Request::is('admin/absensi') ? 'active' : ''); ?>">
                <i class="nav-icon fas fa-edit"></i>
                <p>
                  Absensi Siswa
                </p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/jadwal" class="nav-link <?php echo e(Request::is('admin/jadwal') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-calendar-check"></i>
            <p>
              Jadwal Mata Pelajaran
            </p>
          </a>
        </li>
        
        <li class="nav-item">
          <a href="/admin/rapot" class="nav-link <?php echo e(Request::is('admin/rapot') ? 'active' : ''); ?>">
            <i class="nav-icon far fa-image"></i>
            <p>
              E - Rapot
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/tagihan" class="nav-link <?php echo e(Request::is('admin/tagihan') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-columns"></i>
            <p>
              Tagihan
            </p>
          </a>
        </li>
        <li class="nav-item has-treeview <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'menu-open' : ''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Point Siswa
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/point" class="nav-link <?php echo e(Request::is('admin/point') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon" style="font-size: 14px"></i>
                <p>Data Point</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/pointSiswa" class="nav-link <?php echo e(Request::is('admin/pointSiswa') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon"  style="color: lightgreen; font-size:14px"></i>
                <p>Data Point Siswa</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/modul" class="nav-link <?php echo e(Request::is('admin/modul') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-book"></i>
            <p>
              Modul Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/guru" class="nav-link <?php echo e(Request::is('admin/guru') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-search"></i>
            <p>
              Data Guru
            </p>
          </a>
        </li>
        <?php elseif($user->role == 'kesiswaan'): ?>
        <li class="nav-item">
          <a href="/admin/siswa" class="nav-link <?php echo e(Request::is('admin/siswa') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>
              Data Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/informasi" class="nav-link <?php echo e(Request::is('admin/informasi') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-info-circle"></i>
            <p>
              Informasi Sekolah
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/absensi" class="nav-link <?php echo e(Request::is('admin/absensi') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-edit"></i>
            <p>
              Absensi Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/rapot" class="nav-link <?php echo e(Request::is('admin/rapot') ? 'active' : ''); ?>">
            <i class="nav-icon far fa-image"></i>
            <p>
              E - Rapot
            </p>
          </a>
        </li>
        <li class="nav-item has-treeview <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'menu-open' : ''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Point Siswa
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/point" class="nav-link <?php echo e(Request::is('admin/point') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon" style="font-size: 14px"></i>
                <p>Data Point</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/pointSiswa" class="nav-link <?php echo e(Request::is('admin/pointSiswa') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon"  style="color: lightgreen; font-size:14px"></i>
                <p>Data Point Siswa</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/berita" class="nav-link <?php echo e(Request::is('admin/berita') ? 'active' : ''); ?>">
            <i class="nav-icon far fa-plus-square"></i>
            <p>
              Berita
            </p>
          </a>
        </li>
        <?php elseif($user->role == 'guru'): ?>
        <li class="nav-item">
          <a href="/admin/siswa" class="nav-link <?php echo e(Request::is('admin/siswa') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-users"></i>
            <p>
              Data Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/absensi" class="nav-link <?php echo e(Request::is('admin/absensi') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-edit"></i>
            <p>
              Absensi Siswa
            </p>
          </a>
        </li>
        <li class="nav-item">
          <a href="/admin/rapot" class="nav-link <?php echo e(Request::is('admin/rapot') ? 'active' : ''); ?>">
            <i class="nav-icon far fa-image"></i>
            <p>
              E - Rapot
            </p>
          </a>
        </li>
        <li class="nav-item has-treeview <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'menu-open' : ''); ?>">
          <a href="#" class="nav-link <?php echo e(Request::is('point*') || Request::is('admin/pointSiswa/*') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-th"></i>
            <p>
              Point Siswa
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="/admin/point" class="nav-link <?php echo e(Request::is('admin/point') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon" style="font-size: 14px"></i>
                <p>Data Point</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="/admin/pointSiswa" class="nav-link <?php echo e(Request::is('admin/pointSiswa') ? 'active' : ''); ?>" style="font-size: 14px">
                <i class="fa fa-check nav-icon"  style="color: lightgreen; font-size:14px"></i>
                <p>Data Point Siswa</p>
              </a>
            </li>
          </ul>
        </li>
        <li class="nav-item">
          <a href="/admin/modul" class="nav-link <?php echo e(Request::is('admin/modul') ? 'active' : ''); ?>">
            <i class="nav-icon fas fa-book"></i>
            <p>
              Modul Siswa
            </p>
          </a>
        </li>
        <?php endif; ?>
      </ul>
    </nav>
    

    <!-- /.sidebar-menu -->
  </div>
  <!-- /.sidebar -->
</aside>
<?php /**PATH C:\laragon\www\admin-siawi\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>