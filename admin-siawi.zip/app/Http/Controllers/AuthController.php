<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Guru;
use App\Models\Setting;
use DB;

class AuthController extends Controller
{
    public function index(){
        if (Auth::check()) {
            return redirect()->route('admin.dashboard.index');
        }
    
        // Jika belum login, tampilkan halaman login
        // return view('login');
        $setting = Setting::find('1');
        return view('auth.login', compact('setting'));
    }


    public function login_proses(Request $request) {
        $request->validate([
            'username' => 'required',
            'password' => 'required'
        ]);

        $user = Guru::where('username', $request->username)->first();

        if($user){
            if ($request->password == $user->password) {
                // Autentikasi berhasil, loginkan pengguna
                Auth::login($user);
    
                // Arahkan pengguna ke dashboard atau lokasi yang sesuai
                return redirect('/admin/dashboard')->with('success','Berhasil Login');
            }
        }

        return redirect()->route('login')->with('failed', 'Username dan password salah');
    }

    public function logout(){
        Auth::logout();
        return redirect()->route('login')->with('success', 'logout berhasil');
    }

    // public function store(Request $request) {
    //     // dd($request->all());
    //     $request->validate([
    //         'username' => 'required',
    //         'password' => 'required'
    //     ]);

    //     $username = $request->username;
    //     $password = $request->password;

    //     $user = Guru::where('username', $username)->where('password', $password)->first();
    //     // $credentials = $request->only('username', 'password');
    
    //     if ($user) {
    //         // Jika login berhasil, buat session untuk pengguna
    //         $request->session()->put('user', $user);

    //         return redirect('/dashboard');
    //     } else {
    //         // Jika login gagal, kembalikan ke halaman login dengan pesan error
    //         return back()->withErrors(['login' => 'Email or password is incorrect']);
    //     }
    // }
}
